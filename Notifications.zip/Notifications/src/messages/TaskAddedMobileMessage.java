package messages;

public class TaskAddedMobileMessage extends TaskAdded {

	public String prepareMessage(String[] placeHolders) {
		// code to replace place holders of this type
		String msg = "Task: " + placeHolders[0] + ",due date: " + placeHolders[1] + ",teamDescription:"
				+ placeHolders[2];
		return msg;
	}

}