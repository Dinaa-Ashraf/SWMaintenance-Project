package messages;

public class GradesAnnouncementEmailMessage extends GradesAnnouncement {

	public String prepareMessage(String[] placeHolder) {
		// code to replace place holders of this type
		return "Dear: " + placeHolder[0] + ",The grades of task : " + placeHolder[1]
				+ ",is announced and you can find it at:" + placeHolder[2];
	}

	public boolean verifyGrades() {
		// code to verify Grades before announcement

		return true;
	}
}