package messages;

public abstract class GradesAnnouncement {

    private String grade;

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getGradePlace() {
        return gradePlace;
    }

    public void setGradePlace(String gradePlace) {
        this.gradePlace = gradePlace;
    }

    private String gradePlace;

    public abstract String prepareMessage(String[] placeHolders);

    public abstract boolean verifyGrades();
}