package gateways;

import messages.DailyNewsEmailMessage;
import messages.GradesAnnouncementEmailMessage;
import messages.TaskAddedEmailMessage;

public class EmailGateway implements Gateway {

	@Override
	public void sendMessage(Object message, String user) {

		if (message instanceof DailyNewsEmailMessage) {
			DailyNewsEmailMessage msg = (DailyNewsEmailMessage) message;
			String[] dailyNewsplaceHolders = new String[] { msg.getNews(), msg.getTime() };
			msg.prepareMessage(dailyNewsplaceHolders);

			// some code to send message
		}

		else if (message instanceof GradesAnnouncementEmailMessage) {
			GradesAnnouncementEmailMessage msg = (GradesAnnouncementEmailMessage) message;
			String[] gradesplaceHolders = new String[] { user, msg.getGrade(), msg.getGradePlace() };
			msg.prepareMessage(gradesplaceHolders);

			// some code to send message
		}

		else if (message instanceof TaskAddedEmailMessage) {
			TaskAddedEmailMessage msg = (TaskAddedEmailMessage) message;
			String[] taskplaceHolders = new String[] { msg.getTaskType(), msg.getDueDate(), msg.getTeamDescription() };
			msg.prepareMessage(taskplaceHolders);

			// some code to send message by email to user
		}

	}
}
