package gateways;

public interface Gateway {
    public void sendMessage(Object message, String user);
}
