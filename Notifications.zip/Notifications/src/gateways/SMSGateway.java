package gateways;

import messages.DailyNewsMobileMessage;
import messages.GradesAnnouncementMobileMessage;
import messages.TaskAddedMobileMessage;

public class SMSGateway implements Gateway {

	@Override
	public void sendMessage(Object message, String user) {

		if (message instanceof DailyNewsMobileMessage) {
			DailyNewsMobileMessage msg = (DailyNewsMobileMessage) message;
			String[] dailyNewsplaceHolders = new String[] { msg.getNews(), msg.getTime() };// set some place holders
																							// here
			msg.prepareMessage(dailyNewsplaceHolders);

			// some code to send message
		}

		else if (message instanceof GradesAnnouncementMobileMessage) {
			GradesAnnouncementMobileMessage msg = (GradesAnnouncementMobileMessage) message;
			String[] gradesplaceHolders = new String[] { user, msg.getGrade(), msg.getGradePlace() };// set some place
																										// holders
			// here
			msg.prepareMessage(gradesplaceHolders);

			// some code to send message
		}

		else if (message instanceof TaskAddedMobileMessage) {
			TaskAddedMobileMessage msg = (TaskAddedMobileMessage) message;
			String[] taskplaceHolders = new String[] { msg.getTaskType(), msg.getDueDate(), msg.getTeamDescription() }; // set
																														// some
			// place
			// holders
			// here
			msg.prepareMessage(taskplaceHolders);

			// some code to send message to user
		}

	}
}
