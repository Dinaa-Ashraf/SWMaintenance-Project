package Messages;

public class TaskAddedEmailMessage extends TaskAdded {

	public String prepareMessage(String[] placeHolder) {
		// code to replace place holders of this type

		return "Task: " + placeHolder[0] + ",due date: " + placeHolder[1] + ",teamDescription:" + placeHolder[2];

	}

}
