package messages;

public abstract class TaskAdded {
    private String TeamDescription;

    public String getTeamDescription() {
        return TeamDescription;
    }

    public void setTeamDescription(String teamDescription) {
        TeamDescription = teamDescription;
    }

    public String getTaskType() {
        return TaskType;
    }

    public void setTaskType(String taskType) {
        TaskType = taskType;
    }

    public String getDueDate() {
        return DueDate;
    }

    public void setDueDate(String dueDate) {
        DueDate = dueDate;
    }

    private String TaskType;
    private String DueDate;

    public abstract String prepareMessage(String[] placeHolders);

    public void addTeamDescription(String TeamDescription) {
        System.out.println(TeamDescription);
    }
}