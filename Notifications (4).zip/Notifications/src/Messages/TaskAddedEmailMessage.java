package Messages;

public class TaskAddedEmailMessage {

	public String prepareMessage(String placeHolders[]) {
		// code to replace place holders of this type
		
		return "";
	}
	
	
	public void addTeamDescription() {
		
	}
}
